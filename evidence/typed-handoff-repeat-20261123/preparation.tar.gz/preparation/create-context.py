import hashlib, json, os, pathlib, sys
root=pathlib.Path('/private/tmp/openwrt-typed-handoff-live-20261123')
codeql=pathlib.Path('/Users/lalbers/gitroot/ucode/.tools/codeql-2.27.4/codeql/codeql')
git=pathlib.Path('/opt/homebrew/Cellar/git/2.56.1/bin/git')
framework=pathlib.Path('/opt/homebrew/Cellar/python@3.15/3.15.2/Frameworks/Python.framework/Versions/3.15/Python')
runner=pathlib.Path('/private/tmp/openwrt-typed-handoff-replay/tools/typed_handoff/runner.py'); verifier=runner.with_name('verify.py')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576), b''): h.update(chunk)
 return h.hexdigest()
def inventory(p):
 if p.is_symlink(): raise ValueError(str(p))
 if p.is_file(): return {'sha256':digest(p),'size':p.stat().st_size}
 out={}
 def error(exc): raise exc
 for d,ds,fs in os.walk(p,onerror=error,followlinks=False):
  for name in sorted(ds+fs):
   f=pathlib.Path(d)/name; rel=str(f.relative_to(p))
   if f.is_symlink(): raise ValueError(str(f))
   if f.is_dir(): out[rel]={'directory':True}
   elif f.is_file() and f.stat().st_nlink==1: out[rel]={'sha256':digest(f),'size':f.stat().st_size}
   else: raise ValueError(str(f))
 return out
inputs={name:str(root/name) for name in ('producer','consumer','source','extractor-pack','packs','python-export','python-consumer','preparation')}
inputs.update({'codeql':str(codeql.parent),'python-framework':str(framework),'git-binary':str(git),'shell':'/bin/sh','env-binary':'/usr/bin/env'})
print('inventorying inputs',flush=True)
initial={k:inventory(pathlib.Path(v)) for k,v in inputs.items()}
old=pathlib.Path('/private/tmp/openwrt-typed-handoff-replay/evidence/typed-handoff-d398198-1f01e0a/oracle-expanded.json')
oracle=json.loads(old.read_text()); oracle['extracted_rows'][1][0]=str(root/'source'/oracle['source'])
oracle_path=root/'retry-oracle.json'
with oracle_path.open('x') as f: json.dump(oracle,f,indent=2);f.write('\n')
run=root/'retry-run'; p=root/'producer'; c=root/'consumer'; s=root/'source'; ep=root/'extractor-pack'; src=p/'ql/src'; lib=p/'ql/lib'; pack=root/'packs'; db=run/'database'; runtime=run/'runtime'; exp=root/'python-export/bin/python3.15'; con=root/'python-consumer/bin/python3.15'
additional=':'.join(str(pack/'codeql'/n/v) for n,v in [('controlflow','1.0.12'),('dataflow','1.1.6'),('regex','1.0.12'),('ssa','1.0.12'),('threat-models','1.1.1'),('typetracking','1.0.12'),('util','1.0.12'),('yaml','1.0.61')])
env={'HOME':str(runtime/'home'),'TMPDIR':str(runtime/'tmp'),'LANG':'C','LC_ALL':'C','PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'}
commands={}
def stage(name,argv,cwd,extra=None): commands[name]={'argv':list(map(str,argv)),'cwd':str(cwd),'env':env| (extra or {})}
stage('init',[codeql,'database','init',db,'--language=ucode','--search-path='+str(ep),'--source-root='+str(s)],p)
stage('index',[codeql,'database','index-files',db,'--language=ucode','--include=**/rpcd/ucode/luci','--working-dir='+str(s)],p,{'CODEQL_UCODE_STAGED_ROOT':str(s)})
stage('finalize',[codeql,'database','finalize',db],p)
for name,query in [('extracted','diagnostics/SuccessfullyExtractedFiles.ql'),('errors','diagnostics/ExtractionErrors.ql'),('effects','m4/SetBlockDetectEffectTable.ql')]:
 stage(name+'_query',[codeql,'query','run',src/query,'--database='+str(db),'--search-path='+':'.join(map(str,[ep,lib,src])),'--additional-packs='+additional,'--no-default-compilation-cache','--compilation-cache='+str(runtime/'compilation-cache'),'--common-caches='+str(runtime/'common-cache'),'--output='+str(run/(name+'.bqrs')),'--threads=1','--ram=2048'],p)
 stage(name+'_decode',[codeql,'bqrs','decode','--format=csv',run/(name+'.bqrs')],p)
stage('export',[exp,'-I','-S','-B','-X','pycache_prefix='+str(runtime/'empty-pycache-export'),p/'tools/export_setblock_detect.py','--csv',run/'effects.csv','--extracted',run/'extracted.csv','--errors',run/'errors.csv','--source-root',s,'--lock',c/'corpus/lock.json'],p)
for name in ('import','reimport'):
 stage(name,[con,'-I','-S','-B','-X','pycache_prefix='+str(runtime/('empty-pycache-'+name)),'-m','policy.setblock_table','--typed-json',run/'typed.json','--source-root',s],c)
outputs={'runtime':'runtime','database':'database','extracted_bqrs':'extracted.bqrs','errors_bqrs':'errors.bqrs','effects_bqrs':'effects.bqrs','extracted':'extracted.csv','errors':'errors.csv','effects':'effects.csv','typed':'typed.json'}
context={'oracle_sha256':digest(oracle_path),'commands':commands,'inputs':inputs,'run':str(run),'initial':initial,'git':{'producer':'d3981986ac685d6fcbb78a3b369aa4ed526c1e4b','consumer':'fe5952073eeef913fef4b3324d9541ff66426492'},'outputs':outputs,'executables':{str(x):digest(x) for x in (codeql,git,exp,con)},'runner_sha256':digest(runner),'verifier_sha256':digest(verifier),'git_executable':str(git),'git_env':{'PATH':'/usr/bin:/bin','LC_ALL':'C','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null','GIT_OPTIONAL_LOCKS':'0'},'runtime_directories':['home','tmp','compilation-cache','common-cache'],'runtime_transitions':{name:(['home','tmp','compilation-cache','common-cache'] if name.endswith('_query') else ['home','tmp']) for name in commands},'required_absent':['runtime/empty-pycache-export','runtime/empty-pycache-import','runtime/empty-pycache-reimport']}
context_path=root/'retry-context.json'
with context_path.open('x') as f: json.dump(context,f,indent=2);f.write('\n')
print('context',digest(context_path),'oracle',digest(oracle_path),'run_absent',not run.exists(),flush=True)
